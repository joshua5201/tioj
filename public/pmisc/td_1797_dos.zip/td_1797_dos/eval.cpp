#include <iostream>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <string>

using namespace std;

typedef pair<int,int> pii;

inline double squ(int a)
{
      return 1.0 * a * a;
}

inline double dist(const pii &a, const pii &b)
{
   return sqrt(squ(a.first - b.first) + squ(a.second - b.second));
}

int main(int argc, char *argv[])
{
   while(true){
      string z;
      cout << "enter testdata no. :";
      cin >> z;
      
      fstream tdin(z+".in");
      pii v[1000];
      int n;
      double t;
      tdin >> z >> n >> t;
      for(int i = 0; i < n; ++i)
         tdin >> v[i].first >> v[i].second;
      
      cout << "enter your answer :";
      int c[1000] = {0};
      for(int i = 0; i < n; ++i)
         cin >> c[i];
      
      ///check
      bool po[1000] = {false};
      int co = 0;
      bool flag = true;
      for(int i = 0; i < n; ++i){
         if(c[i] < n && (po[c[i]] == false)){
            po[c[i]] = true;
            ++co;
         }else{
            cout << "answer format error!" << endl;
            flag = false;
            break;
         }
      }
      if(!flag)
         continue;
      
      ///evaluate
      double ans = 0;
      for(int i = 0; i < n-1; ++i)
         ans += dist(v[c[i]], v[c[i+1]]);
      ans += dist(v[c[0]], v[c[n-1]]);
      cout << "\n=====" << endl;
      cout << "Total Length: " << fixed << setprecision(6) << ans 
           << ", Target Length: " << t << endl;
      if(ans <= t)
         cout << "answer accepted!!" << endl;
      else
         cout << "answer not accepted!" << endl;
      cout << "=====" << endl;
   }
   return 0;
}
